public class CardCondition : ICloneable<CardCondition>
{
    public EffectCondition? EffectCondition { get; set; } = null;
    public bool Enabled { get; set; } = true;

    public CardCondition(EffectCondition? effectCondition, bool enabled)
    {
        EffectCondition = effectCondition?.Clone();
        Enabled = enabled;
    }

    public CardCondition(EffectCondition? effectCondition)
    {
        EffectCondition = effectCondition?.Clone();
    }

    public bool CanPlay(Guid playerId, Guid rivalId, CardInstance sourceCard, GameState state, GameEvent? ev)
    {
        return Enabled && (EffectCondition is null || EffectCondition.Check(playerId, rivalId, sourceCard, state, ev));
    }

    public CardCondition Clone()
    {
        return new CardCondition(EffectCondition, Enabled);
    }
}