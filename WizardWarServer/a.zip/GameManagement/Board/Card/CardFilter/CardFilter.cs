public class CardFilter
{
    public NumberFilter? CurrentAttack { get; set; } = null;
    public NumberFilter? CurrentHealth { get; set; } = null;
    public NumberFilter? Attack { get; set; } = null;
    public NumberFilter? Health { get; set; } = null;
    public ICardType? CardType { get; set; } = null;
    public string[]? Families { get; set; } = null;
    public string[]? CurrentFamilies { get; set; } = null;
    public string? DefinitionId { get; set; } = null;
    public Guid? Id { get; set; } = null;
    public bool? HasEffect { get; set; } = null;
    public int? NumberOfTriggersLeft { get; set; } = null;
    
    public bool MustMeetAllCriteria { get; set; } = false;

    public bool Check(CardInstance card)
    {
        var criteria = new List<bool>();

        if(CardType is not null)
        {
            criteria.Add(CardType.GetType().Equals(card.Type.GetType()));
        }
        if (CurrentAttack is not null && card.Type is ICardType.Unit u)
        {
            criteria.Add(CurrentAttack.Compare(u.Attack));
        }
        if (CurrentHealth is not null && card.Type is ICardType.Unit u2)
        {
            criteria.Add(CurrentHealth.Compare(u2.Health));
        }
        if (Attack is not null && card.Definition.Type is ICardType.Unit u3)
        {
            criteria.Add(Attack.Compare(u3.Attack));
        }
        if (Health is not null && card.Definition.Type is ICardType.Unit u4)
        {
            criteria.Add(Health.Compare(u4.Health));
        }
        if (Families != null)
        {
            if (MustMeetAllCriteria)
            {
                criteria.Add(Families.All(f => card.Definition.Families.Contains(f)));
            }
            else
            {
                criteria.Add(Families.Any(f => card.Definition.Families.Contains(f)));
            }
        }
        if (CurrentFamilies != null)
        {
            if (MustMeetAllCriteria)
            {
                criteria.Add(CurrentFamilies.All(f => card.CurrentFamilies.Contains(f)));
            }
            else
            {
                criteria.Add(CurrentFamilies.Any(f => card.CurrentFamilies.Contains(f)));
            }
        }
        if (DefinitionId != null)
        {
            criteria.Add(card.Definition.Id == DefinitionId);
        }
        if (Id.HasValue)
        {
            criteria.Add(card.Id == Id.Value);
        }
        if (HasEffect.HasValue)
        {
            criteria.Add(card.ActiveEffects is not null);
        }
        if (NumberOfTriggersLeft.HasValue)
        {
            criteria.Add(card.ActiveEffects?.ActiveEffectTriggerTimes == NumberOfTriggersLeft.Value);
        }

        if (criteria.Count == 0)
        {
            return true;
        }

        if (MustMeetAllCriteria)
        {
            return criteria.All(c => c);
        }
        else
        {
            return criteria.Any(c => c);
        }
    }
}