public class ActiveEffects : ICloneable<ActiveEffects>
{
    public ActiveEffects(IEffect[] effects, int activeEffectTriggerTimes)
    {
        Effects = effects;
        ActiveEffectTriggerTimes = activeEffectTriggerTimes;
    }

    public IEffect[] Effects { get; set; } = [];
    public int ActiveEffectTriggerTimes { get; set; } = 0;

    public ActiveEffects Clone()
    {
        return new ActiveEffects
        (
            Effects = [.. Effects.Select(e => e.Clone())],
            ActiveEffectTriggerTimes = ActiveEffectTriggerTimes
        );
    }

    public void Trigger(Guid playerId, Guid rivalId, CardInstance sourceCard, GameState state, GameEvent? ev)
    {
        if (ActiveEffectTriggerTimes <= 0) return;


        foreach(var e in Effects) e.Execute(playerId, rivalId, sourceCard, state, ev);

        ActiveEffectTriggerTimes--;

    }
}