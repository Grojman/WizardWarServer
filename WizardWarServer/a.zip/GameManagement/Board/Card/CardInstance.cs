public class CardInstance : IdentificableObject
{
    public PlayerState Player { get; set; }
    public CardDefinition Definition { get; }
    public List<string> CurrentFamilies { get; set; }
    public List<TriggerEffectInstance> Effects { get; set; }
    public CardCondition CanPlay { get; set; }
    public ActiveEffects? ActiveEffects { get; set; }
    public ICardType Type { get; set; }

    public CardInstance(CardDefinition def, PlayerState player)
    {
        Player = player;
        Definition = def;

        Type = def.Type.Clone();

        CurrentFamilies = [.. def.Families];

        CanPlay = new(def.ConditionToPlay);

        ActiveEffects = def.ActiveEffects?.Clone();

        Effects = new();
        foreach(TriggerEffectInstance e in def.Effects) Effects.Add(e.Clone());

        foreach(TriggerEffectInstance e in Effects) AssignEffect(e);


        if (Type is ICardType.Spell s)
        {
            foreach(EffectInstance e in s.Effects) AssignEffect(e);
        }
    }

    public void AssignEffect(EffectInstance e)
    {
        if (Player is null)
        {
            throw new NullReferenceException("Player is null in CardInstance");
        }
        e.Player = Player;
        e.SourceCard = this;
    }
}