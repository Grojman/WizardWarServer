public class CardDefinition
{
    public CardDefinition()
    {
    }

    public CardDefinition(string id, string name, ICardType type, string description, List<TriggerEffectInstance> effects, string[] families, string imageUrl, EffectCondition? conditionToPlay, ActiveEffects? activeEffects)
    {
        Id = id;
        Name = name;
        Type = type;
        Description = description;
        Effects = effects;
        Families = families;
        this.ImageUrl = imageUrl;
        ConditionToPlay = conditionToPlay;
        ActiveEffects = activeEffects;
    }

    public string[] Families { get; set; } = [];
    public required string Id { get; set; }

    public required string Name { get; set; }

    public required ICardType Type { get; set; }

    public string Description { get; set; } = string.Empty;

    public List<TriggerEffectInstance> Effects { get; set; } = [];

    public string ImageUrl { get; set; } = string.Empty;

    public EffectCondition? ConditionToPlay { get; set; } = null;
    
    public ActiveEffects? ActiveEffects { get; set; } = null;
}