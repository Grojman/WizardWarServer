using System.Text.Json.Serialization;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]

[JsonDerivedType(typeof(Unit), nameof(Unit))]
[JsonDerivedType(typeof(Spell), nameof(Spell))]

public abstract class ICardType : ICloneable<ICardType>
{
    public abstract ICardType Clone();
    public class Unit : ICardType
    {
        public Unit() {}
        public Unit(int health, int attack)
        {
            Health = health;
            Attack = attack;
        }
        public static Unit Empty { get => new();}
        public int Health { get; set; } = 0;
        public int Attack { get; set; } = 0;
        public bool DeathChecked { get; set; } = false;

        public override Unit Clone()
        {
            return new Unit()
            {
                Health = Health,
                Attack = Attack
            };
        }

        public override string ToString()
        {
            return "Unidad";
        }
    }

    public class Spell: ICardType
    {
        public static Spell Empty { get => new();}
        public Spell()
        {
            Effects = [];
        }
        public Spell(EffectInstance[] effects)
        {
            Effects = effects;
        }
        public EffectInstance[] Effects { get; set; }

        public override Spell Clone()
        {
            return new Spell([.. Effects.Select(n => n.Clone())]);
        }

        public void ExecuteEffects(GameState state, GameEvent? ev)
        {
            foreach(var e in Effects) e.TryExecute(state, ev);
        }

        public override string ToString()
        {
            return "Hechizo";
        }
    }
}