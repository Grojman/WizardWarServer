public class PlayerSourceCondition : EffectCondition
{
    public PlayerSourceCondition(bool toRival)
    {
        ToRival = toRival;
    }

    public bool ToRival { get; set; } = false;

    public override bool Check(Guid playerId, Guid rivalId, CardInstance sourceCard, GameState state, GameEvent? ev)
    {
        if (ev is null) return false;

        return ev.PlayerSource.Id == (ToRival ? rivalId : playerId);
    }

    public override EffectCondition Clone() => new PlayerSourceCondition(ToRival);
}