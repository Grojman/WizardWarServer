public class EffectInstance : IdentificableObject, ICloneable<EffectInstance>
{
    public static int counter = 0;
    public static int getCounter() => counter++;
    public int a = getCounter();
    public EffectInstance()
    {
    }

    public EffectInstance(List<IEffect> effect, EffectDuration duration, EffectCondition? condition)
    {
        Effects = effect;
        Duration = duration;
        Condition = condition;
    }

    public List<IEffect> Effects { get; set; } = new();

    public EffectDuration Duration { get; set; } = new Always();
    public EffectCondition? Condition { get; set; } = null;

    public CardInstance SourceCard { get; set; } = null!;

    PlayerState player;
    int contador = 0;

    public PlayerState Player 
    { 
        get => player; 
        set
        {
            Console.WriteLine($"{a} número {contador}:  Updating the value of player: {value}");
            contador++;
            if(player is not null && value is null)
            {
                throw new NullReferenceException("Player is null in EffectInstance");
            }
            if (player is not null)
            {
                
            player = value;
            }
        } 
    }
    public bool Expired { get => Duration.IsExpired(); }

    public string Description { get; set; } = string.Empty;

    public virtual EffectInstance Clone()
    {
        return new()
        {
            SourceCard = SourceCard,
            Player = Player,
            Duration = Duration.Clone(),
            Condition = Condition?.Clone(),
            Effects = [.. Effects.Select(n => n.Clone())]
        };
    }

    public void TryExecute(
        GameState state,
        GameEvent? ev,
        bool checkExpiration = true)
    {
        if (Player is null)
        {
            throw new NullReferenceException("Player is null in EffectInstance");
        }

        if(SourceCard is null)
        {
            throw new NullReferenceException("SourceCard is null in EffectInstance");
        }

        if (Expired && checkExpiration)
            return;

        if (!(Condition?.Check(Player.Id, Player.PlayerTarget!.Id, SourceCard, state, ev) ?? true))
            return;

        if (ev is not null && ev.Source.Id == Id)
            return;


        Effects.ForEach(n => n.Execute(Player.Id, Player.PlayerTarget!.Id, SourceCard, state, ev));

        Duration.NotifyExecution();
    }

    public void ForceExecute(
        GameState state,
        GameEvent? ev,
        bool notifyExec
    )
    {
        Effects.ForEach(n => n.Execute(Player.Id, Player.PlayerTarget!.Id, SourceCard, state, ev));

        if (notifyExec) Duration.NotifyExecution();
    }
}