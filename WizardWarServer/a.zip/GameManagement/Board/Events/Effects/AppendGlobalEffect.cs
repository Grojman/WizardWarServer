
public class AppendGlobalEffect : IEffect
{
    public string Description { get; set; }
    public AppendGlobalEffect(TriggerEffectInstance effect, string description)
    {
        Effect = effect;
        Effect.Description = description;
        Description = description;
    }

    public TriggerEffectInstance Effect { get; set; }
    public IEffect Clone() => new AppendGlobalEffect(Effect.Clone(), Description);

    public void Execute(Guid playerId, Guid rivalId, CardInstance cardId, GameState state, GameEvent? ev)
    {
        cardId.AssignEffect(Effect);
        state.GetState(playerId).GlobalEffects.Add(Effect);
    }
}