public enum TriggerType
{
    TurnEnd,
    DrawCard,
    PlayerHealthChanged,
    UnitHealthChanged,
    UnitDamageChanged,
    UnitPlayed,
    SpellPlayed,
    UnitDeath,
    CardAddedToDeck,
    DeckModified,
    CardAttacked,
    CardEffectPlayed
    
}