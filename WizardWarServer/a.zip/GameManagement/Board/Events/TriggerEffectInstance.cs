public class TriggerEffectInstance : EffectInstance
{
    public TriggerType Trigger { get; set; }
    
    public TriggerEffectInstance()
    {
        
    }

    public TriggerEffectInstance(TriggerType trigger, List<IEffect> effect, EffectDuration duration, EffectCondition? condition) : base(effect, duration, condition)
    {
        Trigger = trigger;
    }

    public override TriggerEffectInstance Clone()
    {
        return new()
        {
            Trigger = Trigger,
            SourceCard = SourceCard,
            Player = Player,
            Duration = Duration.Clone(),
            Condition = Condition?.Clone(),
            Effects = [.. Effects.Select(n => n.Clone())]
        };
    }
}