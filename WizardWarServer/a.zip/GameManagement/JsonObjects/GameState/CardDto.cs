public record CardDto(string id, string name, string description, List<string> families, int attack, int health, string type, string imageUrl, bool canPlay, bool hasEffect, int effectTimes)
{
    public static CardDto Generate(CardInstance card, GameState state, bool dontCheck)
    {
        var a = card.Type as ICardType.Unit;
        int damage = a?.Attack ?? 0;
        int health = a?.Health ?? 0;

        return new CardDto(card.Id.ToString(), card.Definition.Name, card.Definition.Description, card.CurrentFamilies, damage, health, card.Definition.Type.ToString(), string.IsNullOrWhiteSpace(card.Definition.ImageUrl) ? $"{card.Definition.Id}.png" : card.Definition.ImageUrl, dontCheck || (card.CanPlay?.CanPlay(card.Player.Id, card.Player.PlayerTarget!.Id, card, state, null) ?? true), card.ActiveEffects is not null && card.ActiveEffects.Effects.Length > 0, card.ActiveEffects?.ActiveEffectTriggerTimes ?? -1);
    }

    public static CardDto Generate(CardDefinition card)
    {
         var a = card.Type as ICardType.Unit;
        int damage = a?.Attack ?? 0;
        int health = a?.Health ?? 0;

        return new CardDto(card.Id, card.Name, card.Description, card.Families.ToList(), damage, health, card.Type.ToString(), string.IsNullOrWhiteSpace(card.ImageUrl) ? $"{card.Id}.png" : card.ImageUrl, true, card.ActiveEffects is not null && card.ActiveEffects.Effects.Length > 0, card.ActiveEffects?.ActiveEffectTriggerTimes ?? -1);
    }
}